//
//  UserMacroScrollView.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/02/09.
//

import SwiftUI
struct UserMacroScrollView: View {
    @EnvironmentObject private var viewModel: ViewModel
    private var macroCollection: MacroCollection {
        viewModel.configuration.macroCollection
    }
    
    
    let columns = [
        GridItem(.adaptive(minimum: 65 - 65 * 0.07 + 2.5, maximum: 100))
    ]
    var body: some View {
        ScrollView(.vertical) {
            LazyVGrid(columns: columns, spacing: 5) {
                ForEach(macroCollection.collection, id: \.self) { macro in
                    MacroKeyView(macro)
                }
            }
        }
    }
}
