//
//  UserMacrosListView.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/02/09.
//
import SwiftUI

struct UserMacrosListView: View {
    @EnvironmentObject private var viewModel: ViewModel

    
    @State var searchText: String = ""
    
    private var filteredMacros: [Macro] {
        let filtered = searchText.isEmpty
        ? viewModel.configuration.macroCollection.collection
        : viewModel.configuration.macroCollection.collection.filter {
            $0.name.localizedCaseInsensitiveContains(searchText)
        }
        return filtered
    }
    
    var body: some View {
        List(selection: $viewModel.configuration.selections.macro) {
            Section {
                ForEach(filteredMacros, id: \.self) { macro in
                    Group {
                        if macro == viewModel.configuration.selections.macro {
                            TextField(
                                "macro name",
                                text: Binding(
                                    get: { macro.name },
                                    set: { newValue in
                                        macro.name = newValue
                                    }
                                )
                            )
                        } else {
                            Text(macro.name)
                        }
                    }
                    .tag(macro)
                    .contextMenu {
                        Button("Delete", role: .destructive) {
                            if let indexInOriginal = viewModel.configuration.macroCollection.collection.firstIndex(of: macro) {
                                withAnimation {
                                    viewModel.configuration.selections.macro = .initialMacro
                                    viewModel.configuration.macroCollection.collection.remove(at: indexInOriginal)
                                }
                            }
                        }
                    }
                }
                // searchTextが空の時のみonMoveを有効にする
                .if(searchText.isEmpty) { view in
                    view.onMove { indexSet, offset in
                        viewModel.configuration.macroCollection.collection.move(fromOffsets: indexSet, toOffset: offset)
                    }
                }
            } header: {
                HStack {
                    // 検索フィールド→ テキストフィールドに入力した文字でフィルター
                    TextField(text: $searchText) {
                        HStack {
                            Image(systemName: "magnifyingglass")
                            Text("Search Macro")
                        }
                    }.textFieldStyle(.plain)
                    
                    if !searchText.isEmpty {
                        Button(action: { searchText = "" }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.gray.opacity(0.7))
                        }
                        .accessibilityLabel("clear search text")
                        .buttonStyle(.plain)
                    }
                    // 追加ボタン↓
                    Button("Add") {
                        withAnimation {
                            let newMacro = Macro()
                            viewModel.configuration.macroCollection.collection.insert(newMacro, at: 0)
                        }
                    }
                }
            }
        }
        .frame(minWidth: 150, maxWidth: 150)
        .cornerRadius(5)
        .shadow(radius: 2)
//
//        List(filteredMacros, selection: $viewModel.configuration.selections.macro) { macro in
//            Section {
//                Group {
//                    if macro == viewModel.configuration.selections.macro {
//                        TextField(
//                            "macro name",
//                            text: Binding(
//                                get: { macro.name },
//                                set: { newValue in
//                                    macro.name = newValue
//                                }
//                            )
//                        )
//                    } else {
//                        Text(macro.name)
//                    }
//                }
//                .contextMenu {
//                    Button("Delete", role: .destructive) {
//                        if let indexInOriginal = viewModel.configuration.macroCollection.collection.firstIndex(of: macro) {
//                            withAnimation {
//                                viewModel.configuration.selections.macro = .initialMacro
//                                viewModel.configuration.macroCollection.collection.remove(at: indexInOriginal)
//                            }
//                        }
//                    }
//                }
//                // searchTextが空の時のみonMoveを有効にする
//                .if(searchText.isEmpty) { view in
//                    view.onMove { indexSet, offset in
//                        viewModel.configuration.macroCollection.collection.move(fromOffsets: indexSet, toOffset: offset)
//                    }
//                }
//            } header: {
//                HStack {
//                    // 検索フィールド→ テキストフィールドに入力した文字でフィルター
//                    TextField(text: $searchText) {
//                        HStack {
//                            Image(systemName: "magnifyingglass")
//                            Text("Search Macro")
//                        }
//                    }.textFieldStyle(.plain)
//                    
//                    if !searchText.isEmpty {
//                        Button(action: { searchText = "" }) {
//                            Image(systemName: "xmark.circle.fill")
//                                .foregroundColor(.gray.opacity(0.7))
//                        }
//                        .accessibilityLabel("clear search text")
//                        .buttonStyle(.plain)
//                    }
//                    // 追加ボタン↓
//                    Button("Add") {
//                        withAnimation {
//                            let newMacro = Macro()
//                            viewModel.configuration.macroCollection.collection.insert(newMacro, at: 0)
//                        }
//                    }
//                }
//            }
//        }
//        .frame(minWidth: 150, maxWidth: 150)
//        .cornerRadius(5)
//        .shadow(radius: 2)

    }
}
