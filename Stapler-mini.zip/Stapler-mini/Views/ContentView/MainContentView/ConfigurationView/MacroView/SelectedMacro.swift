//
//  SelectedMacro.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/02/09.
//

import SwiftUI

struct SelectedMacro_ToDetail_macrosView: View {
    @EnvironmentObject private var viewModel: ViewModel

//    @Binding var macro: Macro
    let keySize: CGFloat
    
    private var keyMetrics_1u: KeyMetrics {
        KeyMetrics(unitSize: 1, baseSizeX: keySize)
    }
    private var keyMetrics_15: KeyMetrics {
        KeyMetrics(unitSize: 1.5, baseSizeX: keySize)
    }
    
    @State var nextIndicator: Bool = false

    var body: some View {
        List {
            if viewModel.configuration.selections.macro.toDetailCollection.collection.isEmpty {
                OnHoverButtonView(
                    symbolName: "plus",
                    hoverColor: Color.accentColor,
                    size: CGSize(width: keyMetrics_15.frameWidth / 3, height: keyMetrics_15.frameHeight / 3)
                ) {
                    let newToDetail = [
                        ToDetail_macro(output: .letter_keys(.h)),
                        ToDetail_macro(output: .letter_keys(.e)),
                        ToDetail_macro(output: .letter_keys(.l)),
                        ToDetail_macro(output: .letter_keys(.l)),
                        ToDetail_macro(output: .letter_keys(.o)),
                        ToDetail_macro(output: .shift_symbols(.exclamation)),
                    ]
                    viewModel.configuration.selections.macro.toDetailCollection.collection.append(contentsOf: newToDetail)
                }
                .dropDestination(for: DragClass.self) { items, location in
                    guard let item = items.first else { return false }
                    if let custom = item.customizeKey {
                        let newToDetail = ToDetail_macro(output: custom.output)
                        viewModel.configuration.selections.macro.toDetailCollection.collection.insert(newToDetail, at: 0)
                        return true
                    }
                    return true
                }
                .frame(height: keyMetrics_1u.frameHeight)
            } else {
                ForEach(viewModel.configuration.selections.macro.toDetailCollection.collection.chunked(into: 10), id: \.self) { chunk in
                    ZStack {
                        HStack(spacing: 0) {
                            ForEach(chunk, id: \.self) { detail in
                                if let elementIndex = viewModel.configuration.selections.macro.toDetailCollection.collection.firstIndex(of: detail) {
                                    ToDetail_macroView(
                                        toDetail: $viewModel.configuration.selections.macro.toDetailCollection.collection[elementIndex],
                                        nextIndicator: $nextIndicator
                                    )
                                    .overlay {
                                        OnHoverButtonView(
                                            symbolName: "trash",
                                            hoverColor: .red,
                                            size: CGSize(width: keyMetrics_15.frameWidth / 4, height: keyMetrics_15.frameHeight / 4)
                                        ) {
                                            withAnimation {
                                                print("elementIndex: \(elementIndex)")
                                                viewModel.configuration.selections.macro.toDetailCollection.collection.remove(at: elementIndex)
                                            }
                                        }
                                        .frame(
                                            width: keyMetrics_1u.frameWidth + keyMetrics_1u.padding_body * 2,
                                            height: keyMetrics_1u.frameHeight + keyMetrics_1u.padding_body * 2,
                                            alignment: .topLeading)
                                    }
                                    .frame(width: keyMetrics_15.frameWidth)
                                    .padding([.top, .bottom], 10)
                                } else {
                                    EmptyView()
                                }
                            }
                        }
                        HStack(spacing: 0) {
                            if chunk.first == viewModel.configuration.selections.macro.toDetailCollection.collection.first {
                                OnHoverButtonView(
                                    symbolName: "plus",
                                    hoverColor: Color.accentColor,
                                    size: CGSize(width: keyMetrics_15.frameWidth / 3, height: keyMetrics_15.frameHeight / 3)
                                ) {
                                    let newToDetail = ToDetail_macro(output: .letter_keys(.a), display: "a")
                                    if let firstElement = chunk.first,
                                       let sectionStartIndex = viewModel.configuration.selections.macro.toDetailCollection.collection.firstIndex(of: firstElement) {
                                        print("sectionStartIndex: \(sectionStartIndex)")
                                        viewModel.configuration.selections.macro.toDetailCollection.collection.insert(newToDetail, at: sectionStartIndex)
                                    }
                                }
                                .dropDestination(for: DragClass.self) { items, location in
                                    guard let item = items.first else { return false }
                                    if let firstElement = chunk.first,
                                       let sectionStartIndex = viewModel.configuration.selections.macro.toDetailCollection.collection.firstIndex(of: firstElement) {
                                        if let custom = item.customizeKey {
                                            let newToDetail = ToDetail_macro(output: custom.output)
                                            viewModel.configuration.selections.macro.toDetailCollection.collection.insert(newToDetail, at: sectionStartIndex)
                                            return true
                                        }
                                    }
                                    return true
                                }
                                .frame(height: keyMetrics_1u.frameHeight)
                            } else {
                                Spacer()
                                    .frame(
                                        width: keyMetrics_15.frameWidth / 3,
                                        height: keyMetrics_1u.frameHeight
                                    )
                            }
                            
                            
                            ForEach(chunk, id: \.self) { detail in
                                Spacer()
                                    .frame(
                                        width: keyMetrics_15.frameWidth - keyMetrics_15.frameWidth / 3,
                                        height: keyMetrics_15.frameHeight - keyMetrics_15.frameHeight / 3
                                    )
                                if detail == viewModel.configuration.selections.macro.toDetailCollection.collection.last {
                                    OnHoverButtonView(
                                        symbolName: "plus",
                                        hoverColor: Color.accentColor,
                                        size: CGSize(width: keyMetrics_15.frameWidth / 3, height: keyMetrics_15.frameHeight / 3)
                                    ) {
                                        let newToDetail = ToDetail_macro(output: .letter_keys(.a), display: "a")
                                        viewModel.configuration.selections.macro.toDetailCollection.collection.append(newToDetail)
                                    }
                                    .dropDestination(for: DragClass.self) { items, location in
                                        guard let item = items.first else { return false }
                                        if let elementIndex = viewModel.configuration.selections.macro.toDetailCollection.collection.firstIndex(of: detail) {
                                            if let custom = item.customizeKey {
                                                let newToDetail = ToDetail_macro(output: custom.output)
                                                viewModel.configuration.selections.macro.toDetailCollection.collection.append(newToDetail)
                                            }
                                        }
                                        return true
                                    }
                                    .frame(height: keyMetrics_1u.frameHeight)
                                    .overlay {
                                        RecordingIndicatorView(indicator: nextIndicator, keyMetrics: keyMetrics_1u, keyShape: .square)
                                            .offset(x: keyMetrics_1u.padding_keytop * 3, y: keyMetrics_1u.padding_keytop * 3)
                                    }
                                } else {
                                    OnHoverButtonView_replace(
                                        nonHoverSymbolName: "arrow.right",
                                        hoverSymbolName: "plus",
                                        hoverColor: Color.accentColor,
                                        size: CGSize(width: keyMetrics_15.frameWidth / 3, height: keyMetrics_15.frameHeight / 3)
                                    ) {
                                        let newToDetail = ToDetail_macro(output: .letter_keys(.a), display: "a")
                                        if let elementIndex = viewModel.configuration.selections.macro.toDetailCollection.collection.firstIndex(of: detail) {
                                            print("elementIndex: \(elementIndex)")
                                            viewModel.configuration.selections.macro.toDetailCollection.collection.insert(newToDetail, at: elementIndex + 1)
                                        }
                                    }
                                    .dropDestination(for: DragClass.self) { items, location in
                                        guard let item = items.first else { return false }
                                        if let elementIndex = viewModel.configuration.selections.macro.toDetailCollection.collection.firstIndex(of: detail) {
                                            if let custom = item.customizeKey {
                                                let newToDetail = ToDetail_macro(output: custom.output)
                                                viewModel.configuration.selections.macro.toDetailCollection.collection.insert(newToDetail, at: elementIndex + 1)
                                                return true
                                            }
                                        }
                                        return true
                                    }
                                    .frame(height: keyMetrics_1u.frameHeight)
                                }
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.plain)
//        .scrollContentBackground(.hidden)
        .cornerRadius(5)
        .shadow(radius: 2)
    }
}
