//
//  MacroView.swift
//  Stapler-mini ViewExamples3
//
//  Created by qdpb on 2025/01/08.
//

import SwiftUI
import Combine

extension Array {
    func chunked(into size: Int) -> [[Element]] {
        stride(from: 0, to: count, by: size).map {
            Array(self[$0..<Swift.min($0 + size, count)])
        }
    }
}


struct MacroView: View {
    @EnvironmentObject private var viewModel: ViewModel
    
//    @Binding var macroArray: [Macro]
//    @Binding var selectedMacroID: UUID?
    
    @State private var searchText: String = ""
    
    private var filteredAndSortedMacros: [Macro] {
        let filtered = searchText.isEmpty
        ? viewModel.configuration.macroCollection.collection
        : viewModel.configuration.macroCollection.collection.filter {
            $0.name.localizedCaseInsensitiveContains(searchText)
        }
        return filtered
    }
    
    private var keyMetrics_15: KeyMetrics {
        KeyMetrics(unitSize: 1.2, baseSizeX: viewModel.configuration.displayKeySize)
    }
    private var keyMetrics_1u: KeyMetrics{ viewModel.keyMetrics }
    private var keyboardMonitor: KeyboardMonitor {
        viewModel.keyboardMonitor
    }
    var body: some View {
        HStack {
            UserMacrosListView().padding()
            Spacer()
            Group {
                if viewModel.configuration.isMacroSelected {
                    SelectedMacro_ToDetail_macrosView(keySize: 50)
                } else {
                    VStack {
                        Text("Macro is Key Seaquence that can be apply to Remap and Combo.")
                            .font(.headline)
                            .foregroundStyle(.secondary)
                        Group {
                            Text("You can type seaquence of key with one stroke if you apply macro to Remap or Combo.")
                            Text("Select or Add Macro from left List.")
                        }
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                }
            }
            .padding()
            Spacer()
        }
        .frame(maxHeight: 400)
    }
}
struct OnHoverButtonView: View {
    let symbolName: String
    let hoverColor: Color
    let size: CGSize
    @State private var onHover: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: {
            action()
        }) {
            Image(systemName: symbolName)
                .resizable() // サイズ変更可能に
                .scaledToFit() // 縦横比を維持
                .frame(width: size.width * 0.6, height: size.height * 0.6) // アイコンの適切なサイズ
                .foregroundColor(onHover ? .white :.secondary)
                .opacity(onHover ? 1.0 : 0.5)
                .padding(size.width * 0.2) // 内側の余白
                .background(Circle().fill(onHover ? hoverColor.opacity(1.0) : Color.gray.opacity(0.1))) // 背景を丸く
                .scaleEffect(onHover ? 1.1 : 1) // ホバー時に拡大
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            if hovering {
                withAnimation {
                    onHover = true
                }
            } else {
                withAnimation {
                    onHover = false
                }
            }
        }
        .frame(width: size.width, height: size.height)
    }
}

struct OnHoverButtonView_replace: View {
    let nonHoverSymbolName: String
    let hoverSymbolName: String
    let hoverColor: Color
    let size: CGSize
    @State private var onHover: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: {
            action()
        }) {
            Image(systemName: onHover ? hoverSymbolName : nonHoverSymbolName)
                .resizable() // サイズ変更可能に
                .scaledToFit() // 縦横比を維持
                .frame(width: size.width * 0.6, height: size.height * 0.6) // アイコンの適切なサイズ
                .foregroundColor(onHover ? .white :.secondary)
                .opacity(onHover ? 1.0 : 0.5)
                .padding(size.width * 0.2) // 内側の余白
                .background(Circle().fill(onHover ? hoverColor.opacity(1.0) : Color.clear)) // 背景を丸く
                .scaleEffect(onHover ? 1.1 : 1) // ホバー時に拡大
                .contentTransition(.symbolEffect(.replace))
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            if hovering {
                withAnimation {
                    onHover = true
                }
            } else {
                withAnimation {
                    onHover = false
                }
            }
        }
        .frame(width: size.width, height: size.height)
    }
}



struct ToDetail_macroView: View {
    @EnvironmentObject private var viewModel: ViewModel

//    @Binding var macro: Macro
    @Binding var toDetail: ToDetail_macro
    
    private var keyMetrics: KeyMetrics {
        KeyMetrics(unitSize: 1, baseSizeX: viewModel.configuration.displayKeySize)
    }
    private var keyboardMonitor: KeyboardMonitor {
        viewModel.keyboardMonitor
    }
    
    @Binding var nextIndicator: Bool
    @State var showPopover: Bool = false

    var body: some View {
        Button(action: {
            withAnimation {
                viewModel.configuration.selections.toDetail_macro = toDetail
            }
        }) {
            KeyTopView(isSelected: viewModel.configuration.selections.toDetail_macro == toDetail)
                .overlay {
                    HStack(spacing: 0) {
                        ModifierContentView(withModifier: toDetail.withModifier, keyMetrics: keyMetrics, color: .white)
                        SFSymbolOrTextView(
                            symbolName: toDetail.outputAndDisplay.display,
                            isSFSymbol: toDetail.outputAndDisplay.isSFSymbol,
                            size: keyMetrics.fontSize_tap,
                            color: .white
                        )
                    }
                    RecordingIndicatorView(indicator: toDetail.indicator, keyMetrics: keyMetrics, keyShape: .square)
                }
                .frame(width: keyMetrics.frame_keytop.width, height: keyMetrics.frame_keytop.height)
                .onTapGesture(count: 2, perform: {
                    print("double clicked")
                    viewModel.configuration.selections.toDetail_macro = toDetail
                    
                    keyboardMonitor.startMonitoring_ToDetail_Macro_Next(
                        toDetail: $toDetail,
                        macro: $viewModel.configuration.selections.macro,
                        configuration: $viewModel.configuration,
                        nextIndicator: $nextIndicator
                    )
                })
                .modifier(SelectedOnHover(isSelected: viewModel.configuration.selections.toDetail_macro == toDetail, showPopover: $showPopover))
                .popover(isPresented: $showPopover, content: {
                    ModifierToggleView(withModifier: $toDetail.withModifier)
                        .padding()
                })
                .dropDestination(for: DragClass.self) { items, location in
                    guard let item = items.first else { return false }
                    if let custom = item.customizeKey {
                        print("customizeKey dropped!")
                        toDetail.applyCustom(from: custom)
                        return true
                    } else if let _ = item.macro {
                        print("macro dropped!")
                        return false
                    }
                    
                    return true
                }
       }
        .buttonStyle(.plain)
        .frame(width: keyMetrics.frameWidth, height: keyMetrics.frameHeight)

    }
}
