//
//  PresetView.swift
//  Stapler-mini ViewExamples3
//
//  Created by qdpb on 2024/12/08.
//
import SwiftData
import SwiftUI

struct ConfigurationView: View {
    @EnvironmentObject private var viewModel: ViewModel
    @Bindable var configuration: Configuration
    
    private var keyMetrics: KeyMetrics { viewModel.keyMetrics }
    @State var isSheetPresented_Export: Bool = false

    var body: some View {
        if viewModel.configuration != .initialConfig {
            VStack(spacing: 5) {
                HStack {
                    Picker("CustomTab", selection: $configuration.selections.tab) {
                        ForEach(SelectedTab.allCases, id: \.self) { type in
                            Text(type.displayString()).tag(type)
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()
                    .frame(maxWidth: 800)
                    
                    OnHoverButtonView(symbolName: "questionmark", hoverColor: .accentColor, size: CGSize(width: 20, height: 20)) {
                        print("open URL of how to use")
                    }
                }
                // キーボードの上に表示するビュー
                Group {
                    if configuration.selections.tab == .remap || configuration.selections.tab == .combo {
                        SelectConditionAndLayerView(
                            conditionDetailCollection: $configuration.conditionDetailCollection,
                            selections: $configuration.selections
                        )
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                
                // キーボードとコンボのリスト、メインなコンテンツ
                HStack {
                    Group {
                        if configuration.selections.tab == .combo {
                            ComboListView()
                                .transition(.move(edge: .trailing).combined(with: .opacity))
                        }
                        
                        if configuration.selections.tab == .macro {
                            MacroView()
                                .transition(.move(edge: .leading).combined(with: .opacity))
                        } else {
                            AllDeviceView(keymap: $configuration.keymap)
                                .transition(.move(edge: .trailing).combined(with: .opacity))
                        }
                    }
                }
                
                // 下に常時表示するカスタム用のキー
                CustomizeKeyAndMacroKeyView()
                    .transition(.opacity)
            }
            .toolbar {
                ToolbarItem {
                    Button {
                        isSheetPresented_Export = true
                    } label: {
                        Label("export configuration", systemImage: "square.and.arrow.up")
                    }
                }
            }
            .sheet(isPresented: $isSheetPresented_Export) {
                ExportSheetView()
            }
            .padding()
            .navigationTitle(viewModel.configuration.name)
            .animation(.default, value: configuration.selections.tab) // アニメーション適用
        } else {
            IntroductionView()
        }
    }
    
}
