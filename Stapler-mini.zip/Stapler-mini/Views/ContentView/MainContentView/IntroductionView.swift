//
//  IntroductionView.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/04/03.
//

import SwiftUI

struct IntroductionView: View {
    let messages = [
        "Stapler-mini is an application for generating JSON configuration files for Karabiner-Elements. With an intuitive interface and visually clear GUI, you can create and apply complex settings for remapping, layers, combos, and macros—without directly editing JSON files.",
        "Stapler-mini was developed to make layer customization intuitive for any keyboard recognized by Karabiner-Elements.",
        "Stapler-mini enables conditional customization based on active applications, IME status, and the number of fingers on a trackpad—thanks to the powerful capabilities of Karabiner-Elements. This level of flexibility is difficult to achieve with a standalone custom keyboard.",
        "Stapler-mini allows you to customize up to three devices simultaneously. Since many users operate both a mouse and a keyboard at the same time, it makes sense to provide full customization for such scenarios."
    ]
    
    var body: some View {
        VStack {
            
            HStack {
                Text("Select configuration or Add one from + Button.")
                    .font(.headline)
                
            }
            .padding()
            
            Text(messages.randomElement() ?? "")
                .font(.caption)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center) // 左寄せ（中央なら .center）
                .lineLimit(nil) // 行数制限なしで折り返し
//                .frame(width: 450) // 幅いっぱいにする
            
            HStack {
                Image(nsImage: NSApp.applicationIconImage)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
            }
            
            Button("How to Use this Application") {
                
            }
            .buttonStyle(.link)
            .padding()

        }
    }
}

#Preview {
    IntroductionView()
}

