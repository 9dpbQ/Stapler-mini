//
//  MainContentView.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/02/03.
//

import SwiftUI

/// User ConfigurationかStored Configurationのどちらかを表示する
//struct MainContentView: View {
//    @EnvironmentObject private var viewModel: ViewModel
//
//    var body: some View {
//        switch viewModel.configurationType {
//        case .userConfiguration:
//            ConfigurationView()
//        default:
//            Text("Stored Config here")
//            // Typeを引数に渡してビューとして成立するような感じにする
////            StoredConfigurationView(storedConfig: loadInternalConfiguration(type: viewModel.configurationType))
//        }
//    }
//}


//struct StoredConfigurationView: View {
//    @EnvironmentObject private var viewModel: ViewModel
//    
//    @State var storedConfig: Configuration
//    
//    private var keyMetrics: KeyMetrics {
//        KeyMetrics(unitSize: 1, baseSizeX: storedConfig.displayKeySize)
//    }
//    
//    var body: some View {
//        VStack {
//            HStack {
//                Text(storedConfig.name).font(.largeTitle)
//                Button("Edit this Configuration") {
//                    print("Edit button pressed")
//                }
//            }
//                
//            keyboardView
//            Text("ここに配列の説明など")
//        }
//    }
//    private var keyboardView: some View {
//        HStack(spacing: 0) {
//            //テンキー
//            if storedConfig.deviceSections.containsSection(.other) {
//                rowsKeyView(for: $storedConfig.keymap.other.mainRows)
//            }
//            if storedConfig.deviceSections.containsSection(.other) && storedConfig.deviceSections.containsSection(.main) {
//                Divider()
//                    .frame(height: storedConfig.displayKeySize * 6)
//            }
//            //メインキーボード
//            if storedConfig.deviceSections.containsSection(.main) {
//                rowsKeyView(for: $storedConfig.keymap.main.mainRows)
//            }
//            
//            if storedConfig.deviceSections.containsSection(.main) && storedConfig.deviceSections.containsSection(.mouse) {
//                Divider()
//                    .frame(height: storedConfig.displayKeySize * 6)
//            }
//            //マウス
//            if storedConfig.deviceSections.containsSection(.mouse) {
//                rowsKeyView(for: $storedConfig.keymap.mouse.mainRows)
//            }
//        }
//    }
//    private func getRow(for rows: Binding<Rows>,at index: RowIndex) -> Binding<[KeyboardKey]> {
//        switch index {
//        case .row1: return rows.row1
//        case .row2: return rows.row2
//        case .row3: return rows.row3
//        case .row4: return rows.row4
//        case .row5: return rows.row5
//        case .row6: return rows.row6
//        }
//    }
//    private func rowsKeyView(for rows: Binding<Rows>) -> some View {
//        ZStack(alignment: .topLeading) {
//            ForEach(RowIndex.allCases, id: \.self) {rowIndex in
//                VStack(alignment: .leading, spacing: 0) {
//                    let row = getRow(for: rows, at: rowIndex)
//                    if row.isEmpty {
//                        EmptyView()
//                    } else {
//                        ForEach(0..<rowIndex.indexValue(), id: \.self) { _ in
//                            //インデックス分のスペーサーを用意
//                            Spacer()
//                                .frame(
//                                    width: keyMetrics.frame.width * rows.wrappedValue.sumOfUnitSize(rowIndex: rowIndex),
//                                    height: keyMetrics.frame.height
//                                )
//                        }
//                        HStack(alignment: .top, spacing: 0) {
//                            ForEach(row.indices, id: \.self) { keyIndex in
//                                KeyboardKeyView(keyboardKey: row[keyIndex])
//                            }
//                            if rows.wrappedValue.enableArrowKeys && (rows.wrappedValue.rowIndex_arrow == rowIndex) {
//                               //ここにArrowがこのRowにあるようならarrowビューを呼び出す感じ？
//                                ArrowsView(
//                                    left: rows.arrow_left,
//                                    right: rows.arrow_right,
//                                    up: rows.arrow_up,
//                                    down: rows.arrow_down
//                                )
//                                .contextMenu {
//                                    Button("disable arrow Keys") {
//                                        print("disable arrow keys")
//                                        rows.wrappedValue.enableArrowKeys = false
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
