//
//  StoredConfigurationView.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/04/06.
//

import SwiftUI

struct StoredConfigurationsListView: View {
    let addAction: (_ storedConfig: StoredConfiguration, _ region: KeycodeRegion) -> Void
    @State var selectedKeyboardRegion: KeycodeRegion = .ANSI
    let storedConfigs: [StoredConfiguration]
    @State var selectedStoredConfiguration: StoredConfiguration? = nil
    
    
    var body: some View {
        VStack {
            HStack {
                Picker("Keyboard layout", selection: $selectedKeyboardRegion) {
                    ForEach(KeycodeRegion.allCases, id: \.self) { region in
                        Text(region.layoutName())
                    }
                }
                .pickerStyle(.segmented)
                .labelsHidden()
                .frame(width: 250)
                .disabled(selectedStoredConfiguration == nil)

                Button("import") {
                    if let config = selectedStoredConfiguration {
                        addAction(config, selectedKeyboardRegion)
                    }
                }
                .disabled(selectedStoredConfiguration == nil)
            }
            .padding(.top)
            List(selection: $selectedStoredConfiguration) {
                ForEach(storedConfigs, id: \.self) { storedConfig in
                    StoredConfigurationView(storedConfig: storedConfig, selectedKeyboardRegion: selectedKeyboardRegion)
                        .tag(storedConfig)
                }
//                .listRowSeparator(.hidden)
                
            }
            .scrollContentBackground(.hidden)
        }
    }
}

struct StoredConfigurationView: View {
    let storedConfig: StoredConfiguration
    let selectedKeyboardRegion: KeycodeRegion
    
    var body: some View {
        HStack {
            Spacer()
            VStack {
                Text(storedConfig.configurationTitle())
                    .font(.largeTitle)
                HStack {
                    Image(storedConfig.imageFileURL(selectedKeyboardRegion))
                        .resizable()
                        .scaledToFit()
                        .frame(width: 500)
                        .cornerRadius(10)
                    Button(storedConfig.webURL()) {
                        openURL(urlString: storedConfig.webURL())
                    }
                    .buttonStyle(.link)
                    .frame(width: 150)
                }
            }
            Spacer()
        }
    }
    private func openURL(urlString: String) {
        guard let url = URL(string: urlString) else {
            print("❌ 無効なURL: \(urlString)")
            return
        }
        NSWorkspace.shared.open(url)
    }
}
