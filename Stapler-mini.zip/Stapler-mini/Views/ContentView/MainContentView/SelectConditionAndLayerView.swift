//
//  SelectConditionAndLayerView.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/02/10.
//
import SwiftUI

struct SelectConditionAndLayerView: View {
    @Binding var conditionDetailCollection: ConditionDetailCollection
    @Binding var selections: Selections
    var body: some View {
        VStack {
            List {
                HStack {
                    Picker("Specific Condition", selection: $selections.condition) {
                        ForEach(SpecificCondition.allCases, id: \.self) { condition in
                            Text(conditionDetailCollection.getConditionDetail(condition).name).tag(condition)
                        }
                    }
                    .labelsHidden()
                    .pickerStyle(MenuPickerStyle())
                    .frame(width: 200)
                    
                    if selections.condition != .condition0 {
                        
                        Toggle(
                            isOn: Binding(
                                get: {
                                    conditionDetailCollection.getConditionDetail(selections.condition).isEnabled
                                },
                                set: { newValue in
                                    conditionDetailCollection.getConditionDetail(selections.condition).isEnabled = newValue
                                }
                            )
                        ) {
                            TextField("Condition Name",
                                      text: Binding(
                                        get: {
                                            conditionDetailCollection.getConditionDetail(selections.condition).name
                                        },
                                        set: { newValue in
                                            conditionDetailCollection.getConditionDetail(selections.condition).name = newValue
                                        }
                                      )
                            )
                            .disabled(!conditionDetailCollection.getConditionDetail(selections.condition).isEnabled)
                            .textFieldStyle(.roundedBorder)
                        }
                        Picker(
                            "Conditions",
                            selection:
                                Binding(
                                    get: { conditionDetailCollection.getConditionDetail(selections.condition).type },
                                    set: { newValue in
                                        conditionDetailCollection.getConditionDetail(selections.condition).type = newValue
                                    }
                                )
                        ) {
                            ForEach(ConditionType.allCases, id: \.self) { type in
                                Text(type.rawValue).tag(type)
                            }
                        }
                        .labelsHidden()
                        .pickerStyle(.segmented)
                        .disabled(!conditionDetailCollection.getConditionDetail(selections.condition).isEnabled)
                        
                        
                        Text(conditionDetailCollection.getConditionDetail(selections.condition).type.textFieldDescription)
                            .frame(width: 60, alignment: .trailing)
                            .foregroundStyle(conditionDetailCollection.getConditionDetail(selections.condition).isEnabled ? .primary : Color.gray)
                        TextField(
                            conditionDetailCollection.getConditionDetail(selections.condition).type.placeholder,
                            text: Binding(
                                get: {
                                    conditionDetailCollection.getConditionDetail(selections.condition).value
                                },
                                set: { newValue in
                                    conditionDetailCollection.getConditionDetail(selections.condition).value = newValue
                                }
                            )
                        )
                        .disabled(!conditionDetailCollection.getConditionDetail(selections.condition).isEnabled)
                        .textFieldStyle(.roundedBorder)
                    } else {
                        Spacer()
                    }
                }
            }
            .scrollDisabled(true)
            .scrollContentBackground(.hidden)
            .frame(maxWidth: 800, maxHeight: 40)

            HStack {
                Spacer()
                SelectLayerButtonViews()
                Spacer()
            }
            .frame(maxWidth: 800)
        }
        .frame(maxHeight: 90)
    }
}
