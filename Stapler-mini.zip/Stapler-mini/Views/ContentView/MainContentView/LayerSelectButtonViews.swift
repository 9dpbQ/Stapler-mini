//
//  LayerSelectButton.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/03/17.
//

import SwiftUI

struct SelectLayerButtonViews: View {
    @EnvironmentObject private var viewModel: ViewModel
    var body: some View {
        HStack {
            ForEach(Layer.allCases, id: \.self) { layer in
                LayerSelectButton(layer: layer) {
                    viewModel.configuration.selections.layer = layer
                }
            }
        }
    }
}

struct LayerSelectButton: View {
    let layer: Layer
    let action: () -> Void

    var body: some View {
        Button(action: {
            action()
        }) {
            Text(layer.displayName)
                .foregroundStyle(.black)
        }
        .buttonStyle(LayerButtonStyle(layer: layer))
    }
}

#Preview {
    @Previewable @StateObject var viewModel = ViewModel() // ViewModelを初期化
    SelectLayerButtonViews()
        .environmentObject(viewModel)
        .padding()
}

struct LayerButtonStyle: ButtonStyle {
    @EnvironmentObject private var viewModel: ViewModel
    let layer: Layer
    func makeBody(configuration: ButtonStyle.Configuration) -> some View {
        configuration.label
            .padding()
            .frame(width: 80, height: 30)
            .background(
                ParallelogramShape()
                    .fill(
                        layer == viewModel.configuration.selections.layer
                        ? layer.accentColor
                        : .gray
                    )
                    .shadow(color: .black.opacity(configuration.isPressed ? 0.1 : 0.3),
                            radius: configuration.isPressed ? 2 : 4,
                            x: configuration.isPressed ? 1 : 2,
                            y: configuration.isPressed ? 1 : 2)
            )
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

struct ParallelogramShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        let skewAmount: CGFloat = rect.maxX * 0.15
        
        path.move(to: CGPoint(x: skewAmount, y: rect.minY))//左上から時計まわりに
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX - skewAmount, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))
        path.addLine(to: CGPoint(x: skewAmount, y: rect.minY))
        
        return path
    }
}
