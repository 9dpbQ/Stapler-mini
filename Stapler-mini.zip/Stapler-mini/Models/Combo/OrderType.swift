//
//  ComboCollection.swift
//  Stapler-mini ViewExamples3
//
//  Created by qdpb on 2024/12/07.
//

import SwiftUI
import SwiftData











enum OrderType: String, Codable, CaseIterable {
    case strict
    case strict_inverse
    case insensitive
}
