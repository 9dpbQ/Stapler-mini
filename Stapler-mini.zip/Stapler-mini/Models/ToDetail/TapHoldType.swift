//
//  TapHoldType.swift
//  Stapler-mini ViewExamples5
//
//  Created by qdpb on 2025/02/16.
//
import SwiftUI
import SwiftData

enum TapHoldType: String, CaseIterable, Codable {
    case chord
    case duration
}
